import React, { Component } from 'react'
//container
export default class StatefulApp extends Component {
    state={
           data: [
            { "id":101,"name":"Murthy",'balance':50000},
            { "id":102,"name":"Lalitha",'balance':60000},
            { "id":103,"name":"Rajesh",'balance':75000},
           ]
    }
  render() {
    return (
        <>
           <h3 className="bg-success text-light">Account Holder Details</h3>
           <table className="table  table-hover  table-striped">
            
            <tbody>
                {
                    this.state.data.map( (customer,index)=> 
                               <TableRow key={index} dataProp={customer} />)
                }
            </tbody>
           </table>
      </>
    )
  }
}
//=============================
//presentation   private component
const TableRow = (props)=>{
    return (
        <tr>
               <td>{props.dataProp.id}</td>
               <td>{props.dataProp.name}</td>
               <td>{props.dataProp.balance}</td>
        </tr>
    )
}


