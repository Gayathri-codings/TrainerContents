import React, { Component } from 'react'
//Parent  rcc
export default class ChildParentInvoke extends Component {

    state={data:'initial data'}
    //handler
    updateState(event){
        this.setState({data:event.target.value})
    }
    //addToCart(prod){ make ajax calls with fetch or axios to rest api}
    //removeFromCart()
  render() {
    return (
      <div className="bg-warning" >
        <h3 className="text-success">Parent Component</h3>
        <h4>Data: {this.state.data}</h4>
        <br/>
        <h3 className="text-danger">Child Components</h3>
        <Content dataProp={this.state.data} 
            updateStateProp={(event)=>this.updateState(event)} ></Content>

        <ContentSibling dataProp={this.state.data}></ContentSibling>
  
      </div>
    )
  }
}
//=================================
//Child1   Search :presentation  rfac
export const Content= (props) => {
  return (
    <div>
     Customer ID: <input type="text" value={props.dataProp} 
     onChange={props.updateStateProp}
     />
    </div>
  )
}


//Child2   Grid : presentation
export const ContentSibling = (props) => {
  return (
    <div className="bg-success">
     <h2>{props.dataProp}</h2>
    </div>
  )
}
