import React, { unstable_Profiler as Profiler } from 'react';
//to show the output use this link:  
//https://codesandbox.io/s/7jroojkv30?file=/src/index.js
export class CustomProfiler extends React.Component {
    state = {
        count: 0
    };
    logProfile = (id, phase, actualTime, baseTime, startTime, commitTime) => {
        var x="murthy"
  
        console.log(`${id}'s ${phase} phase:`);
        console.log(`Actual time: ${actualTime}`);
        console.log(`Base time: ${baseTime}`);
        console.log(`Start time: ${startTime}`);
        console.log(`Commit time: ${commitTime}`);
    };
    go = direction => () => this.setState(({ count }) => ({
        count: direction === "up" ? count + 1 : count - 1
    }));
render() {
        return (
            <Profiler id="app" onRender={this.logProfile}>
                <button onClick={this.go("up")}>☝️</button>
                <div>The count is {this.state.count}</div>
                <button onClick={this.go("down")}>👇</button>
            </Profiler>
        );
    }
}
