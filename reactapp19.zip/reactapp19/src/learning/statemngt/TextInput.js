import React, { Component } from 'react'
import TextDisplay from './TextDisplay'

export default class TextInput extends Component {
    state={inputText:'Murthy'}
    handleChange(event){
        this.setState({inputText:event.target.value})
    }
  render() {
    return (
      <div>
        <h3>Form Details</h3>
        Company: <input type="text" id="txt1"/>
        <br/>
        Info: <input type="text" value="BOA offers low interest rates"/>
        <br/>
        Username: 
        <input type="text"  value={this.state.inputText}
        onChange={ (event)=>this.handleChange(event)}
        />
        {this.state.inputText ? console.log('Valid data') : console.log('Invalid data')}

        {this.state.inputText 
                    ? <TextDisplay textProp={this.state.inputText}/>
                     : <TextDisplay textProp="Enter Username please"/>
        }
      </div>
    )
  }
}


