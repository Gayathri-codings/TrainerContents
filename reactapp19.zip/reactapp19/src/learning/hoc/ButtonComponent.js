import React, { Component } from 'react'
import withIncrement from './withIncrement'

 class ButtonComponent extends Component {
  render() {
    return (
      <div>
       <h3>Testing HOC</h3>
       <button className="btn btn-danger" onClick={this.props.incrementProp}>
         Clicked {this.props.countProp} times
       </button>
      </div>
    )
  }
}
export default withIncrement(ButtonComponent)