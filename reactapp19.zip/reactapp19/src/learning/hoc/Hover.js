import React, { Component } from 'react'
import withIncrement from './withIncrement'

 class Hover extends Component {
  render() {
    return (
      <div>
       <h3>Testing HOC</h3>
       < h3 className="bg-warning" onMouseOver={this.props.incrementProp}>
         Hovered {this.props.countProp} times :)
       </h3>
      </div>
    )
  }
}
export default withIncrement(Hover)