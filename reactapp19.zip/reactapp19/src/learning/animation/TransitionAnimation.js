import React, { useState } from 'react'; 
import { CSSTransition } from 'react-transition-group'; 
import './animate.css';
 function TransitionAnimation() { 
    const [show, setShow] = useState(false); 
    return (
         <div className="App"> 
            <button onClick={() => setShow(!show)}>Toggle</button>
             <CSSTransition 
                 in={show} timeout={300}
                 classNames="fade" unmountOnExit > 
                <div className="box">Animate me!</div>
             </CSSTransition> 
            </div>
         );
 }
export default TransitionAnimation;