import React, { useState } from 'react'; 
import { useSpring, animated } from '@react-spring/web'; 
import './animate.css'
function SpringAnimation() { 
   const [show, setShow] = useState(false); 

   const props = useSpring(
       { opacity: show ? 1 : 0, transform: show
           ? 'translateX(0px)'
            : 'translateX(-100px)', config: { duration: 500 }, 
        }); 

    return ( 
    <div className="App">
         <button onClick={() => setShow(!show)}>Toggle</button> 
         <animated.div style={props} className="box"> Bank of America </animated.div>
     </div>
     );
 }
 export default SpringAnimation;