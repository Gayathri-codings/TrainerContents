import React from 'react'; 
import './animate.css';
function SimpleAnimation() {
     return (
         <div className="App"> 
         <div className="box">Animate me!</div> </div> 
  );
 } ;

 export default SimpleAnimation;