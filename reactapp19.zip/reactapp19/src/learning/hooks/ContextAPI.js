
import {useState,createContext,useContext} from 'react'

//step1: create the context (we can have more than one conext)
const UserContext=createContext();
const SecurityContext=createContext()


export default function ContextAPI(){
    const [user,setUser]=useState('Murthy')
    //step2: create context provider with initial state

    return(
        <UserContext.Provider value={user}>
            <h3>{` Welcome ${user}!  to Bank of America `}</h3>
            <Family/>
        </UserContext.Provider>
    )
}

//==============================

function Family(){
    return (
        <>
        <h3 className="bg-info container"> I am Family component</h3>
        <Component1/>
        </>
    )
}
//=========================================
function Component1(){
      //consumer 
      const user=useContext(UserContext)
      return (
        <>
        <h3 className="bg-success text-light">I am grand child consumer</h3>
        <h4>  {` Welcome ${user}!  ,  I am a deep level component `}</h4>
        </>
      )
}
