import React, { useReducer } from 'react'
//store
const initialState={count:1}
function reducer(state,action){
    switch(action.type){
        case 'INC':
            return {count:state.count+action.payload}
        case 'DEC':
            return {count:state.count-action.payload}
        default:return state
    }
}

const UseReducerDemo = () => {
    const [state,dispatch]=useReducer(reducer,initialState)
  return (
    <div className="container bg-warning">
         <h3>UseReducer Demo</h3>
         <h4>Count: {state.count}</h4>
         <button className="btn btn-success" 
               onClick={ ()=>dispatch( {type:"INC",payload:10})}>INCREMENT
         </button>
         <button className="btn btn-danger" 
               onClick={ ()=>dispatch( {type:"DEC",payload:10})}>DECREMENT
         </button>
    </div>
  )
}

export default UseReducerDemo