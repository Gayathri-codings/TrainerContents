import React, { useActionState } from "react";

async function submitAction(prevState, formData) {
  const name = formData.get("name")?.toString().trim() || "";

  if (!name) {
    return {
      message: "Please enter a name.",
      ok: false,
      name: "",
    };
  }

  await new Promise((resolve) => setTimeout(resolve, 500));

  return {
    message: `Hello, ${name}! Welcome to the useActionState demo.`,
    ok: true,
    name,
  };
}

export default function UseActionStateDemo() {
  const [state, formAction, isPending] = useActionState(submitAction, {
    message: "Enter your name and submit.",
    ok: false,
    name: "",
  });

  return (
    <div style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h2>useActionState Demo</h2>

      <form action={formAction}>
        <input
          type="text"
          name="name"
          defaultValue={state.name}
          placeholder="Your name"
          style={{ marginRight: "0.5rem", padding: "0.5rem" }}
        />
        <button type="submit" disabled={isPending}>
          {isPending ? "Submitting..." : "Submit"}
        </button>
      </form>

      <p
        style={{
          marginTop: "1rem",
          color: state.ok ? "green" : "#333",
          fontWeight: state.ok ? "bold" : "normal",
        }}
      >
        {state.message}
      </p>
    </div>
  );
}
