//useMemo() = caching =memoization (fib(40)) - performance by avoding
//calculation for the same inputvalue(Dependency), do not re-render

import React,{useMemo,useState} from 'react'
 
const expensiveFunction= (inputValue)=>{
    //do a complex time consuming operation logic here 
   // let expensiveValue=inputValue*42
   let expensiveValue="Bank of america index value: 45.45"
   return expensiveValue
}
const Memo = (props) => {
    const [inputValue,setInputValue]=useState(' ') //dependency 
    const result=useMemo( ()=>expensiveFunction(inputValue),[inputValue]);
  return (
    <div>
        <h2> Hi! {result}</h2>
    </div>
  )
}
export default Memo