
/*
useCallback is a React hook that allows you to memoize a function 
so that it is only re-created when one of its dependencies changes. 
This can help improve the performance of your React components,
 especially in cases where the function
 is passed down as a prop to a child component that re-renders frequently.
*/
import React, { useState, useCallback, useMemo } from "react";

const Field = ({ disabled }) => {
  const [message, setMessage] = useState("");

  const handleAlert = useMemo(() => {
    if (disabled) {
      return undefined;
    }
    return () => alert(message);
  }, [message, disabled]);

  const handleFieldChange = useCallback(event => {
    setMessage(event.target.value);
  }, []);

  return (
    <div>
      <p>
        <button onClick={handleAlert} disabled={disabled}>
          Display Message
        </button>
      </p>
      <textarea
        value={message}
        onChange={handleFieldChange}
        disabled={disabled}
      />
    </div>
  );
};

const MemoCallback = () => {
  const [disabled, setDisabled] = useState(false);

  const handleDisable = useCallback(() => {
    setDisabled(disabled => !disabled);
  }, []);

  return (
    <div>
      <p>Alert station</p>
      <p>
        <button onClick={handleDisable}>
          {disabled ? "Enable" : "Disable"} field
        </button>
      </p>
      <Field disabled={disabled} />
    </div>
  );
};

export default MemoCallback

