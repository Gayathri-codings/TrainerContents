import React from 'react'
import useFetch from './useFetch'
const TestHook = () => {
    const url='https://jsonplaceholder.typicode.com/users'
    const {loading,error,data=[]}=useFetch(url)

    if (error) return <h4 className="text-danger">Error has occurred</h4>
    if(loading) return <h4>Loading...... please wait</h4>

  return (
    <div className='bg-dark text-light'>
        <h3 className="bg-warning">Data from REST API with Custom Hook</h3>
        <ul>
            {
                data?.map( item => ( 
                    <li key={item.id}>{item.name} - {item.email}</li>
                ))
            }
        </ul>
    </div>
  )
}

export default TestHook