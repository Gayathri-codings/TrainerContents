//yup formik with @material/core   (RMUI)  - React.Slick
import React ,{forwardRef} from 'react'

//const ChildRef =React.forwardRef( (props,ref) => {
const ChildRef=(props,ref)=>{
  return (
    <div>
        <h1>Welcome </h1>
      <input type="text" ref={ref}/>
    </div>
  )
} 

export default forwardRef(ChildRef)// Higher Order Component (HOC/HOF)
//connect  react with redux