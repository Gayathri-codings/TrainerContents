//lifecycle methods
//componentDidMount and getDerivedStateFromProps,componentWillUnmount
//useEffect
import React,{useState,useEffect} from 'react'

const DataLoader = (props) => {
    const [users,setUsers]=useState([])  //constructor
    
    useEffect( ()=>{
         fetch('https://jsonplaceholder.typicode.com/users')
            .then(response => response.json())
            .then(data=>setUsers(data))
    },[] )
  return (
    <div>
            <ul>
                {users.map( el =>(<li key={el.id}>
                     {el.username} - {el.email}
                       </li>
                       ))}
            </ul>
    </div>    
  )  }
export default DataLoader