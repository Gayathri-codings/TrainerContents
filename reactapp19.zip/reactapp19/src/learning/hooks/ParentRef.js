/*
Ref forwarding is allowing parent component to acces child component as ref
used to hide html elements, add css and state etc.
It is advanced version of useRef.

Create ParentRef.js
create ChildRef.js
when u click on button, we get value in child input box.
*/
import ChildRef from './ChildRef'  //import child in parent 
import React, { useRef } from 'react'

const ParentRef = () => {
   const inputRef=useRef(null)

   function updateInput(){
    inputRef.current.value=1000
    inputRef.current.style.color="red"
    inputRef.current.focus()
   }
  return (
    <div>
        <h2>Ref Forwarding in React</h2>
        <ChildRef ref={inputRef}/>
        <button onClick={updateInput}> Update inputbox</button>
    </div>
  )
}

export default ParentRef