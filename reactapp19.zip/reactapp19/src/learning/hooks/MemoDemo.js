import { useMemo, useRef, useState } from "react"


const expensiveFunction = (inputValue) =>{
    let value= inputValue*1000
     return value
}

function MemoDemo ( {data}) {
    const [inputValue,setInputValue] = useState(100)

    const txtValue=useRef()

    const expensiveValue= useMemo(
        ()=> expensiveFunction(inputValue), 
        [ inputValue]
    );
    
     const handler= ()=>{
        setInputValue(txtValue.current.value)
     }

     
    return (
        <>
        <h2>useMemo Demo</h2>
        Value: <input type="text"  ref={txtValue}/>
        <button onClick={handler}>Calculate</button>
        <h2 className="bg-info">The Expensive result is : {expensiveValue}</h2>

        </>
    )
}
export default MemoDemo