import React, { useState, useMemo } from 'react';

 // Example data
  const items = [
    { id: 1, name: 'Monitor', category: 'A' }, 
    { id: 2, name: 'Printer', category: 'B' }, 
    { id: 3, name: 'Keyboard', category: 'A' },
    ];
    
 const FilterSortComponent = () => { 
    const [filter, setFilter] = useState(''); 
    const [sortBy, setSortBy] = useState('name');
    
    // Memoized filter function 
    const filteredItems = useMemo(() => {
         console.log('Filtering items'); 
         return items.filter(item =>
             item.name.toLowerCase().includes(filter.toLowerCase()));
         }, [filter]);         
         // Recompute only when 'filter' changes 
         
         // Memoized sort function 
         const sortedItems = useMemo(() => { 
            console.log('Sorting items'); 
            return [...filteredItems].sort((a, b) => {
                 if (a[sortBy] < b[sortBy]) return -1; 
                 if (a[sortBy] > b[sortBy]) return 1; 
                 return 0; }); 
            }, [filteredItems, sortBy]); // Recompute only when 'filteredItems' or 'sortBy' changes 
            
        return ( 
        <div> 
            <input type="text"
                  placeholder="Filter items" 
                  value={filter} 
                  onChange={e => setFilter(e.target.value)} /> 
                  
            <select value={sortBy} 
                      onChange={e => setSortBy(e.target.value)}> 
                         <option value="name">Name</option> 
                         <option value="category">Category</option> 
            </select> 

            <ul> 
                {
                sortedItems.map(item => ( 
                <li key={item.id}>{item.name} - {item.category}</li>
                 ))
                }
             </ul>
         </div>
         );
     }; 
    export default FilterSortComponent;  

    /*
Filtering: The filteredItems array is computed only when the filter state changes. 
The useMemo hook helps to avoid re-filtering the items unnecessarily 
if the filter state has not changed.

Sorting: The sortedItems array is computed based on the filteredItems 
     and the sortBy state. Since filteredItems is itself memoized, this ensures 
      that sorting is only recalculated when necessary.

Dependencies: Notice how the dependencies for useMemo are carefully managed:

  - filteredItems dependency ensures sorting is recalculated when the list changes 
     due to filtering.

-   sortBy dependency ensures sorting is recalculated when the sorting criteria change.


    */