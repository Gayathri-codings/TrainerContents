import React, { Component } from 'react'
//container : Stateful Class Component  <CompLifeCycle/>
export default class CompLifeCycle extends Component {
   state={data:0,msg:'Bank of America in profits'}

   updateState(event){
    this.setState({data:this.state.data+1})
   }
  render() {
    return (
      <div className="container bg-info">
         <button className="btn btn-success" 
            onClick={ (event)=>this.updateState(event)}>Increment</button>
        <h5>Data: {this.state.data} - Message: {this.state.msg}</h5>

        <Child dataProp={this.state.data}></Child>

      </div>
    )
  }
}
//=======================================================

class Child extends Component {
    //1. init
    constructor(props){
      super(props)
      this.state={username:'sriram' ,hasError:true,msg:'Sorry... error '}
      console.log(`in Constructor of child :${props.dataProp}`)//0
    }
    
    //2. render
  render() {
    return (
      <div className="container bg-light">
        <h3>Child Component</h3>
        Counter:<h4 id="txt1">{this.props.dataProp}</h4>
        <h4>{this.state.username} - {this.state.address} - {this.state.email} </h4>
      </div>
    )
  }

   //3. cDM
   componentDidMount(){
    //fired only once, make ajax calls to REST API to inititalize data and render
    //subcribe to web socket, observable,custom events......
    console.log(`in cDM of child :${this.props.dataProp}`)//0
   }

   //4. gDSFP 
   static getDerivedStateFromProps(props,state){
    console.log(`in  gDSFP of child :${props.dataProp} - ${state.username}`)
    //called every time when state/props changes
    //props and state validation, live data make ajax calls 
    //fetch(url+props.data).then(response=>this.setState({data:response))
    return {address:'Hyderabad',email:'sri@gmail.com'}
   }

   //5. sCU
   shouldComponentUpdate(props,state){
    //this is invoked every time whenever state/props changes
    //decide weather to render or not when state /prop changes
     if ( props.dataProp>5)
          return true
    else
        return false
   }

   componentDidCatch(error){
     //called only when error occurs. log error in DB with ajax call
     console.log(`Some error occured : ${error}`)
   }

   static getDerivedStateFromError(error){
    // is called during render phase when DOM has not yet been updated.
    // should be ued for rendering a fallback UI
      return {hasError:true,msg:'Sorry... error '}
   }
   //6.cDU
   componentDidUpdate(){
  // this is called every time when state/prop changed 
  //you can access real DOM with javascript/jquery
  //UI manipulations 
   console.log(document.getElementById("txt1").innerText)
   }

   //7. cWU
   componentWillUnmount(){
      //called only once when we remove component from virtual DOM
      //clear the cache , unsubscribe to web sockets, observables
      //to avoid memory leak
   }
}
