//Stateless Functional Component = SFC = Presentation=No state
import React from 'react'
export const Footer  = ()=>{
    //useState
    return (
        <div className="bg-dark  text-light  text-center">
            <h5>Copyright Reserved to Dr. DSR Murthy</h5>
        </div>
    )
}

