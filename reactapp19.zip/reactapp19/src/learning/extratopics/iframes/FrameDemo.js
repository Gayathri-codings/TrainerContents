import React, { useRef, useState } from 'react'

const FrameDemo = () => {
    const baseUrl="https://www.wikipedia.org"
    const iframeRef=useRef(null)
    const[url,setUrl]=useState(baseUrl)

    const handleLoad = ()=>{
        alert("Iframe loaded successfully")
        //axios.get(url).then(resp...)
    }

    const getFrameInfo = () =>{
        console.log(iframeRef.current)
    }

  return (
    <div>
        Enter URL: 
        <input type="text" value={url} 
                 onChange={ (event)=> setUrl(event.target.value)}
                 style={  {width:'60%', boxSizing:'border-box',background:'lightblue'}}/>
       
       <iframe  ref={iframeRef} src={url}
            title="Dynamic Frame"
            width="80%" height="500"  
            sandbox="allow-scripts allow-forms"/>

            <button className="btn btn-primary" 
                    onClick={getFrameInfo}>Get Frame info</button>

    </div>
  )
}

export default FrameDemo