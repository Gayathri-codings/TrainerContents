import React, { useState } from 'react';
import './Login.css';
import { fakeLogin } from './authUtils';

/* ── Validation helpers ── */
function validateEmail(value) {
  if (!value.trim()) return 'Email is required';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) return 'Enter a valid email address';
  return '';
}

function validatePassword(value) {
  if (!value) return 'Password is required';
  if (value.length < 6) return 'Password must be at least 6 characters';
  return '';
}

/* ── Dashboard shown after login ── */
function Dashboard({ user, token, onLogout }) {
  const [copied, setCopied] = useState(false);

  function handleCopy() {
    navigator.clipboard.writeText(token);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <div className="dashboard-page">
      <div className="dashboard-card">
        <div className="dashboard-header">
          <h2>Dashboard</h2>
          <button className="logout-btn" onClick={onLogout}>Logout</button>
        </div>

        <div className="success-banner">
          <span>✅</span>
          <span>Login successful! JWT token generated.</span>
        </div>

        <div className="user-info">
          <div className="avatar">{user.name.charAt(0)}</div>
          <div className="user-details">
            <h3>
              {user.name}
              <span className="role-badge">{user.role}</span>
            </h3>
            <span>{user.email}</span>
          </div>
        </div>

        <div className="token-section">
          <h4>Your JWT Token</h4>
          <div className="token-box">
            <button className="copy-btn" onClick={handleCopy}>
              {copied ? '✓ Copied' : 'Copy'}
            </button>
            {token}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ── Login form ── */
export default function Login() {
  const [fields, setFields] = useState({ email: '', password: '' });
  const [errors, setErrors] = useState({ email: '', password: '' });
  const [touched, setTouched] = useState({ email: false, password: false });
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [loading, setLoading] = useState(false);
  const [serverError, setServerError] = useState('');
  const [authData, setAuthData] = useState(null);

  function handleChange(e) {
    const { name, value } = e.target;
    setFields((prev) => ({ ...prev, [name]: value }));
    if (touched[name]) {
      const validate = name === 'email' ? validateEmail : validatePassword;
      setErrors((prev) => ({ ...prev, [name]: validate(value) }));
    }
  }

  function handleBlur(e) {
    const { name, value } = e.target;
    setTouched((prev) => ({ ...prev, [name]: true }));
    const validate = name === 'email' ? validateEmail : validatePassword;
    setErrors((prev) => ({ ...prev, [name]: validate(value) }));
  }

  function validate() {
    const emailErr = validateEmail(fields.email);
    const passErr = validatePassword(fields.password);
    setErrors({ email: emailErr, password: passErr });
    setTouched({ email: true, password: true });
    return !emailErr && !passErr;
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!validate()) return;

    setLoading(true);
    setServerError('');
    try {
      const data = await fakeLogin(fields.email, fields.password);
      setAuthData(data);
    } catch (err) {
      setServerError(err.message);
    } finally {
      setLoading(false);
    }
  }

  if (authData) {
    return (
      <Dashboard
        user={authData.user}
        token={authData.token}
        onLogout={() => setAuthData(null)}
      />
    );
  }

  return (
    <div className="login-page">
      <div className="login-card">
        {/* Header */}
        <div className="login-logo">
          <div className="logo-icon">🔐</div>
          <h1>Welcome back</h1>
          <p>Sign in to your account to continue</p>
        </div>

        {/* Server error */}
        {serverError && (
          <div className="server-error">
            <span>⚠️</span>
            <span>{serverError}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} noValidate>
          {/* Email */}
          <div className="form-group">
            <label htmlFor="email">Email Address</label>
            <div className="input-wrapper">
              <span className="input-icon">📧</span>
              <input
                id="email"
                type="email"
                name="email"
                placeholder="you@example.com"
                value={fields.email}
                onChange={handleChange}
                onBlur={handleBlur}
                className={errors.email && touched.email ? 'input-error' : ''}
                autoComplete="email"
              />
            </div>
            {errors.email && touched.email && (
              <p className="field-error"><span>⛔</span>{errors.email}</p>
            )}
          </div>

          {/* Password */}
          <div className="form-group">
            <label htmlFor="password">Password</label>
            <div className="input-wrapper">
              <span className="input-icon">🔒</span>
              <input
                id="password"
                type={showPassword ? 'text' : 'password'}
                name="password"
                placeholder="Enter your password"
                value={fields.password}
                onChange={handleChange}
                onBlur={handleBlur}
                className={errors.password && touched.password ? 'input-error' : ''}
                autoComplete="current-password"
              />
              <button
                type="button"
                className="toggle-password"
                onClick={() => setShowPassword((p) => !p)}
                aria-label="Toggle password visibility"
              >
                {showPassword ? '🙈' : '👁️'}
              </button>
            </div>
            {errors.password && touched.password && (
              <p className="field-error"><span>⛔</span>{errors.password}</p>
            )}
          </div>

          {/* Options */}
          <div className="form-options">
            <label className="remember-me">
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
              />
              Remember me
            </label>
            <a href="#forgot" className="forgot-link">Forgot password?</a>
          </div>

          {/* Submit */}
          <button type="submit" className="login-btn" disabled={loading}>
            {loading ? (
              <>
                <span className="spinner" />
                Signing in…
              </>
            ) : (
              'Sign In'
            )}
          </button>
        </form>

        {/* Demo credentials hint */}
        <div className="demo-hint">
          <strong>Demo credentials</strong>
          Admin: <code>admin@example.com</code> / <code>Admin@123</code>
          <br />
          User: &nbsp;<code>user@example.com</code> / <code>User@123</code>
        </div>
      </div>
    </div>
  );
}
