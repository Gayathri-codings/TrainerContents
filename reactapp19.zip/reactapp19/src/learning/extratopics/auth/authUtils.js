const FAKE_USERS = [
  { email: 'admin@example.com', password: 'Admin@123', name: 'Admin User', role: 'admin' },
  { email: 'user@example.com', password: 'User@123', name: 'John Doe', role: 'user' },
];

function base64Encode(obj) {
  return btoa(JSON.stringify(obj));
}

export function generateFakeJWT(user) {
  const header = base64Encode({ alg: 'HS256', typ: 'JWT' });
  const payload = base64Encode({
    sub: user.email,
    name: user.name,
    role: user.role,
    iat: Math.floor(Date.now() / 1000),
    exp: Math.floor(Date.now() / 1000) + 3600,
  });
  const signature = base64Encode(`fake-signature-${user.email}-${Date.now()}`);
  return `${header}.${payload}.${signature}`;
}

export function fakeLogin(email, password) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const user = FAKE_USERS.find(
        (u) => u.email === email && u.password === password
      );
      if (user) {
        const token = generateFakeJWT(user);
        resolve({ token, user: { name: user.name, email: user.email, role: user.role } });
      } else {
        reject(new Error('Invalid email or password'));
      }
    }, 900);
  });
}
