import React from 'react'
import withIncrement from './withIncrement'

const Hover = (props) => {
  return (
    <div>
        <h3>Testing HOC</h3>
       <h4 className="bg-warning" 
             onMouseOver ={props.incrementProp}>hovered {props.countProp} times</h4>
    </div>
  )
}

export default withIncrement(Hover) //connect in redux