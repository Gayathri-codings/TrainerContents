import React, { Component } from 'react'

export default class ChildParentInvoke extends Component {
    state={data:'Initial data'}

    updateState(event){
       this.setState( {data: event.target.value})
    }

  render() {
    return (
      <div>
        <h3>Parent Component</h3>
        <h5>Data: {this.state.data}</h5>
        <br/>

        <div className="bg-warning container">
            <h4>Child Components</h4>
            <Content dataProp={this.state.data} 
                           updateStateProp={ (event)=> this.updateState(event)}>            
            </Content>

            <br/>
            <ContentSibling info={this.state.data}></ContentSibling>
        </div>
      </div>
    )
  }
}
//-------------------------------------------
const Content= (props)=>{
    return (
        <>
        Enter data:  <input type="text" value={props.dataProp}
                onChange={props.updateStateProp}/>
        </>

    )

}

//-----------------------------------
const ContentSibling= (props)=>{
    return (
            <div className="bg-success text-light">
                <h4>Info: {props.info}</h4>
            </div>
    )
}