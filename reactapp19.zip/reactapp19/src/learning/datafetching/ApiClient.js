// npm install axios --force
import axios from 'axios'
// performance  : local and remote 
// Map() or cookies  or localstorage   - sessionStorage - route cache
const cache= new Map()
//caching invalidation policy
const TTL = 6*60*1000// 6min
//service for api calls
export const fetchUsingCache = async (url,options=null)=>{
    const now=Date.now()
    if (cache.has(url)){
        const {data,timestamp}=cache.get(url)
        // please check if cache is still valid
        if(now - timestamp < TTL) {
            console.log("Serving from cache ",url)
            return data
        } else {
            cache.delete(url)//expired
        }        
    }
     console.log(` Fetching from API: ${url}`)
     const response=  await axios.get(url)
     cache.set(url, {data: response.data,timestamp :now})
     return response.data
}
