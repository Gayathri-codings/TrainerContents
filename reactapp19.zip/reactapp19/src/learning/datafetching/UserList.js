// jsonplaceholder , openweathermap, CMS content with LLM with OpenAI, fakeers,Ollama
import React ,{useEffect, useState} from 'react'
import { fetchUsingCache } from './ApiClient'

const UserList = (props) => {
    const url='https://jsonplaceholder.typicode.com/users'
    const [users,setUsers]= useState( [])// users=[]
    const [loading, setLoading]= useState(true)

    useEffect( () =>{
           const getUsers=  async () =>{
          const data=await  fetchUsingCache(url)
            setUsers(data)
            setLoading(false)
           }
           getUsers()
         
    },[])

    if (loading)   return <p>Loading data..............</p>
    return (
    <ul>
        {
            users.map( (user,index)=> (
                 <li key={user.id}> {user.name} - {user.email}</li>
            ))
        }   
    </ul>
  )
}
export default UserList
