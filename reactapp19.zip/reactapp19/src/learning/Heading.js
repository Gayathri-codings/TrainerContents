//SCC = state Container
import React from 'react'
export default class Heading extends React.Component{
  
    state={username:'Murthy'}
    render(){
        return(
        <div>
            <h3 className="bg-warning text-center">
                SPA Project in React for  {this.props.company}
            </h3>
            <h5 className="text-danger">by { this.state.username}</h5>
        </div>
        )
    }
}
//===============================
Heading.defaultProps={
    company:'Murthy Infotek'
}