/*
 Formik library includes validation with Yup, dynamic field management, 
 and custom hooks.
 
 >npm install formik yup
>npm install @material-ui/core --force

Formik Setup: 
Formik manages the form's state and handle submissions. 
The FieldArray component from Formik is used to handle dynamic fields .

Yup Validation: 
Yup is used to define the validation schema. It ensures that each address field is correctly 
     validated (e.g., street and city are required, postal code is a 5-digit number).

Dynamic Fields: 
The FieldArray component allows adding and removing address fields dynamically.

Material-UI Components:
 For styling and layout, we're using Material-UI components (TextField, Button, Grid).



 consume Myform in App.js
*/
import React from 'react';
import { Formik, Form, Field, FieldArray } from 'formik';
import * as Yup from 'yup';
import { TextField, Button, Grid } from '@material-ui/core';

// Validation Schema
const validationSchema = Yup.object({
  addresses: Yup.array().of(
    Yup.object({
      street: Yup.string().required('Required'),
      city: Yup.string().required('Required'),
      postalCode: Yup.string().required('Required').matches(/^\d{5}$/, 'Must be a 5-digit postal code'),
    })
  ),
});

// Initial Values
const initialValues = {
  addresses: [
    { street: '', city: '', postalCode: '' }
  ],
};

// Form Component
const MyForm = () => {
  const handleSubmit = (values) => {
    console.log('Form Values:', values);
  };

  return (
    <Formik
      initialValues={initialValues}
      validationSchema={validationSchema}
      onSubmit={handleSubmit}
    >
      {({ values, errors, touched }) => (
        <Form className="bg-info">
          <FieldArray name="addresses">
            {({ push, remove }) => (
              <div>
                {values.addresses.map((address, index) => (
                  <div key={index}>
                    <h3>Address {index + 1}</h3>
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <Field
                          as={TextField}
                          name={`addresses.${index}.street`}
                          label="Street"
                          fullWidth
                          helperText={touched.addresses?.[index]?.street && errors.addresses?.[index]?.street}
                          error={touched.addresses?.[index]?.street && Boolean(errors.addresses?.[index]?.street)}
                        />
                      </Grid>
                      <Grid item xs={12}>
                        <Field
                          as={TextField}
                          name={`addresses.${index}.city`}
                          label="City"
                          fullWidth
                          helperText={touched.addresses?.[index]?.city && errors.addresses?.[index]?.city}
                          error={touched.addresses?.[index]?.city && Boolean(errors.addresses?.[index]?.city)}
                        />
                      </Grid>
                      <Grid item xs={12}>
                        <Field
                          as={TextField}
                          name={`addresses.${index}.postalCode`}
                          label="Postal Code"
                          fullWidth
                          helperText={touched.addresses?.[index]?.postalCode && errors.addresses?.[index]?.postalCode}
                          error={touched.addresses?.[index]?.postalCode && Boolean(errors.addresses?.[index]?.postalCode)}
                        />
                      </Grid>
                    </Grid>
                    <Button
                      type="button"
                      onClick={() => remove(index)}
                      variant="outlined"
                      color="secondary"
                    >
                      Remove Address
                    </Button>
                  </div>
                ))}
                <Button
                  type="button"
                  onClick={() => push({ street: '', city: '', postalCode: '' })}
                  variant="outlined"
                >
                  Add Address
                </Button>
              </div>
            )}
          </FieldArray>
          <Button type="submit" variant="contained" color="primary">
            Submit
          </Button>
        </Form>
      )}
    </Formik>
  );
};

export default MyForm;
