import React ,{useRef} from 'react'
import {connect} from 'react-redux'  //container to reducer
import { addInputs,subtractInputs } from '../actions/calcActions'
const Calculator = (props) => {
    const input1=useRef()
    const input2=useRef()
    let intA,intB
  return (
    <div className="bg-info container">
        <h3>Murthy's Calculator</h3>
        <div>
            Input1: <input type="text" placeholder="0" ref={input1} />
        </div>
        <div>
            Input2: <input type="text" placeholder="0" ref={input2} />
        </div>
        <div>
            Output : <input type="text" placeholder="0"  readOnly 
                  value={props.outputProp}/>
        </div>
        <div>
            <button onClick={ ()=>{
                intA=parseInt(input1.current.value)
                intB=parseInt(input2.current.value)
                props.dispatch(addInputs(intA,intB))
            }}>Add</button>
        </div>
        <div>
            <button onClick={ ()=>{
                intA=parseInt(input1.current.value)
                intB=parseInt(input2.current.value)
                props.dispatch(subtractInputs(intA,intB))
            }}>Subtract</button>
        </div>

    </div>
  )
}



const mapStateToProps= (state)=>({
    outputProp:state.output
})

export default connect(mapStateToProps)(Calculator)