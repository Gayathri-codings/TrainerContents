import { ADD,SUBTRACT } from "../actions/types";
import {addInputs,subtractInputs} from '../actions/calcActions'

describe('Test CalcActions: ',()=>{
    it('addInput test',()=>{
        const add=addInputs(10,20)
        expect(add).toEqual({type:ADD,payload:30})
    })

    it('subtractInput test',()=>{
        const sub=subtractInputs(40,20)
        expect(sub).toEqual({type:SUBTRACT,payload:20})
    })
})
