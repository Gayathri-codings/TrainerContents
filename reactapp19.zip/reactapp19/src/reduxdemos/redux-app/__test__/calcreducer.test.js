import calcReducer from '../reducers/calcReducer'
import {ADD,SUBTRACT} from '../actions/types'

const initialState={
    output:0
}

describe('Test CalcReducer',()=>{
    it('Reducer for ADD',()=>{
        let state={output:0}

        state=calcReducer(0,{type: ADD, payload:50})
           expect(state).toEqual({output:50})

    })

    it('Reducer for Subtract',()=>{
        let state={output:0}

        state=calcReducer(0,{type: SUBTRACT, payload:30})
           expect(state).toEqual({output:30})
    })
})

