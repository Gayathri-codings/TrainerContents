import React, { Component } from 'react';
const baseUrl='http://localhost:5000'
class ClientApp extends Component {

  state = {
    response: '',
    post: '',
    responseToPost: '',
    customers:[]
  };


  componentDidMount() {
   this.getCustomers()
       .then(body=>this.setState({customers:body}))
       .catch(err=>console.log(err))

    this.callApi()
      .then(res => this.setState({ response: res.express }))
      .catch(err => console.log(err));
  }
  //====================
  getCustomers = async () => {
    const response = await fetch(baseUrl+'/api/customers');
    const body = await response.json();

    if (response.status !== 200) throw Error(body.message);

    return body;
  };
  //=================================



  callApi = async () => {
    const response = await fetch(baseUrl+'/api/hello');
    const body = await response.json();

    if (response.status !== 200) throw Error(body.message);

    return body;
  };

  handleSubmit = async e => {
    e.preventDefault();
    const response = await fetch(baseUrl+'/api/world', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ post: this.state.post }),
    });
    const body = await response.text();

    this.setState({ responseToPost: body });
  };

  render() {
    return (
      <div className="bg-warning">
          <h3 className="bg-secondary text-light">{this.state.response}</h3>
        <form onSubmit={this.handleSubmit}>
          <h3>
            <strong>Post to Server:</strong>
          </h3>
          <input
            type="text"
            value={this.state.post}
            onChange={e => this.setState({ post: e.target.value })}
          />
          <button className="btn btn-success" type="submit">Submit</button>
        </form>
        <p>{this.state.responseToPost}</p>

        <h3 className="bg-primary text-light">Customer Details</h3>
       <table className="table table-hover table-striped">
          <tbody>
              {
                this.state.customers.map( (customer,index) =>{
                    return <TableRow key={index} dataProp={customer}/>
                })
              }
          </tbody>
       </table>
      </div>
    );
  }
}

const TableRow= (props) =>{
    return (
        <tr>
            <td>{props.dataProp.id}</td>
            <td>{props.dataProp.name}</td>
            <td>{props.dataProp.city}</td>
        </tr>
    )
}

export default ClientApp;
