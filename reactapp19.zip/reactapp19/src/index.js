



import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';


//import ReactErrorBoundary from './errors/ReactErrorBoundary';
//import Catch from './errors/Catch';

//import { BrowserRouter } from 'react-router-dom';//npm install rrd
import { Provider } from 'react-redux';
//import {store} from './reduxdemos/redux-app/store/config.dev'
import {store} from './reduxdemos/bankapp/store/config.dev'
import BankApp from './reduxdemos/bankapp/BankApp';


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  
  <React.StrictMode>        
      <App/>   
  </React.StrictMode>

);
