import React from 'react'
import { Link } from 'react-router-dom'  //<a>
//rafc
export const Navigation = () => {
  return (
    <div className="navigation bg-secondary">
     <Link className="link" to="/">Home</Link>
     <Link className="link" to="about">About us</Link>
     <Link className="link" to="users">Users</Link>
     <Link className="link" to="lazy">Profile</Link>

    </div>
  )
}
