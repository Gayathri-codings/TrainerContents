import React from 'react'
import { useNavigate } from 'react-router-dom'

export const HomeButton = () => {
    let navigate=useNavigate()

    const handleClick= ()=>{
       // if(sss==null) navigate('/login')
        navigate('/')
    }
  return (
    <div>
        <button className="btn btn-warning" onClick={handleClick}>
            Go to Home</button>
    </div>
  )
}
