import React from 'react'

const Profile = () => {
  return (
    <div className="bg-primary text-light">
        <h3>
            Bank of America started in the year 2000
            GST: 545353744625254534
            Suppport: support@boa.com
        </h3>
    </div>
  )
}

export default Profile