import React from 'react'
import './SpaApp.css'
import { Routes,Route } from 'react-router-dom'
import Home from './pages/Home'
import About from './pages/About'
import Users from './pages/Users'
import UserProfile from './pages/UserProfile'
import Lazy from './pages/Lazy'
const SpaApp = () => {
  return (
    <div className="App">
        <h2>Users Management Project in React </h2>
        <Routes>
            <Route path="/"  element={<Home/>}/>
            <Route path="about"  element={<About/>}/>
            <Route path="users" element={<Users/>}>
                     <Route path=":id" element={<UserProfile/>} /> 
            </Route> 
            <Route path="lazy" element={<Lazy/>}/>
        </Routes>

    </div>
  )
}

export default SpaApp