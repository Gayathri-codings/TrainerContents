import React from 'react'
import {HomeButton} from '../components/HomeButton'
const About = () => {
  return (
    <div className="bg-success text-light">
        <h4>I am About Page</h4>
        <h5>Bank App for managing users ......</h5>
        <HomeButton/>

    </div>
  )
}

export default About