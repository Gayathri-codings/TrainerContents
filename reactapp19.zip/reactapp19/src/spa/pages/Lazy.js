/*
1. npm install react-loadable
2.React.lazy()  //useLazy
3. HOC : Higher Order Component - HOC 
one folder=one module= .js   -> profile.bundle.min.js 
module=collection of components (one container + multiple presentations) = family

*/

import React, { Suspense } from 'react'

const ProfileComponent=React.lazy(()=> import('../profile/Profile'))
const Lazy = () => {
  return (
    <div>
        <h2>I am lazy loaded component</h2>
        <Suspense fallback={<div>Loading profile module... wait</div>}>
              <ProfileComponent/>
        </Suspense>
    </div>
  )
}
export default Lazy
