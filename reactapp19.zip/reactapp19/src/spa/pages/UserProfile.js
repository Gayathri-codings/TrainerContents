import React from 'react'
import { useParams } from 'react-router-dom'

const UserProfile = () => {
    const {id}=useParams()//{id:123,city:'chennai'}
    /*
    useEffect(()=>{
        fetch(url+id)
    })
    */
  return (
    <div className="bg-primary text-warning">
        <h4>Profile of #{id}</h4>
        <h5>I am Murthy  working as senior architect with 25 years experience</h5>
    </div>
  )
}

export default UserProfile