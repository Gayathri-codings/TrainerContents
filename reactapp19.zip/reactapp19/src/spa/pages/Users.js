import React from 'react'
import {HomeButton} from '../components/HomeButton'
import {Outlet,useNavigate,useLocation} from 'react-router-dom'
const Users = () => {
   const navigate=useNavigate()
   const location=useLocation()//window.location.href
   console.log(`Location : ${location.pathname}`)

   const handleClick=(userId)=>{
       navigate(`/users/${userId}`)   //localhost:3000/users/123
   }

  return (
    <div className="bg-warning">
        <h3>Users Page</h3>
        <button className="user-link"
        onClick={ ()=>handleClick('123')}
        > View user profile of #123</button>

        <Outlet/>
        <HomeButton/>
    </div>
  )
}

export default Users