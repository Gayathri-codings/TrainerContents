import './App.css';
import ClientApp from './client/ClientApp';
import { Footer} from './learning/Footer';
import Heading from './learning/Heading';
import ParentRef from './learning/hooks/ParentRef';
/*
import ButtonComponent from './learning/hoc/ButtonComponent';
import Hover from './learning/hoc/Hover';
import ContextAPI from './learning/hooks/ContextAPI';
import UseReducerDemo from './learning/hooks/UseReducerDemo';
import Calculator from './reduxdemos/redux-app/containers/Calculator';
import Timer from './reduxdemos/redux-app/containers/Timer';

import Button from './learning/hooks/Button';
import CompLifeCycle from './learning/lifecycle/CompLifeCycle';
import Weather from './learning/lifecycle/Weather';
import ChildParentInvoke from './learning/statemngt/ChildParentInvoke';
import StatefulApp from './learning/statemngt/StatefulApp';
import TextInput from './learning/statemngt/TextInput';
import TestHook from './learning/hooks/TestHook';
import Memo from './learning/hooks/Memo';
*/
//import SpaApp from './spa/SpaApp';


function App() {
  //const city='Hyd'
  return (
    <div className="App">
     <Heading company="Bank of America" city="Hyderabad"/>
    <ParentRef/>
      
     <Footer/>
    </div>
  );
}

export default App;
//{company:'BOA',city:'Hyd'}

