
import ErrorPage from "./ErrorPage";
import { ErrorBoundary } from "react-error-boundary";
/*
export default function ReactErrorBoundary(props) {
    return (
        <ErrorBoundary
            FallbackComponent={ErrorPage}
            onError={(error, errorInfo) => {
                // log the error
		console.log("Error caught!");  
		console.error(error);  
		console.error(errorInfo);//log to REST api
		
	
            }}
        >
            {props.children}
        </ErrorBoundary>
    );
}
*/


//You can reset after error handled with onReset

export default function ReactErrorBoundary(props) {
    return (
        <ErrorBoundary
            FallbackComponent={ErrorPage}
            onError={(error, errorInfo) => {
                // log the error
				console.log("Error caught!");  
				console.error(error);  
				console.error(errorInfo);
            }}
            onReset={() => {
                // reloading the page to restore the initial state of the current page
                console.log("reloading the page...");
                alert('Reloading react app.....')
                //window.location.reload();
                // other reset logic...
            }}
        >
            {props.children}
        </ErrorBoundary>
    );
}

/*

to use this in index.js

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
 <ReactErrorBoundary>   
  
    <App/>
    </ReactErrorBoundary>
   
  </React.StrictMode>
);
*/
