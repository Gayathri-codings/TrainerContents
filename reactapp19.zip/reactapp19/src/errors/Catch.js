//Catch.js
import React, { Component } from 'react'
/*
To use this Catch , in index.js , add below code
root.render( <Catch><App/> </Catch>)

in App, simulate error

function throwErr(){
  throw new Error('Murthy, there is a API Call Error')
}

in render()  ...  
   <div>{throwErr()}</div>


*/
export default class Catch extends Component {
  state = { hasError: false ,error:''}

  static getDerivedStateFromError(error) { 
    return { hasError: true,error }
  }

  render() {
    if (this.state.hasError) {

      return <h1>{`There was a problem: ${this.state.error.message}`}</h1>
    }

    return this.props.children
  }
}