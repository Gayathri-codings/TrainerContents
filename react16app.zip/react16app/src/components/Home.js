import React from 'react';
import { useBank } from '../context/BankContext';

function Home() {
  const { state } = useBank();
  return (
    <div className="container">
      <h2 class="bg-success text-light">Welcome to Simple Bank</h2>
      <p>Current balance: <strong>${state.balance}</strong></p>
      <p>Use the menu above to deposit, withdraw or check your balance.</p>
        <footer>
        <h6 class="bg-dark text-light text-center">Copyright Reserved. Project done with React 16.x</h6>
      </footer>
    </div>
  );
}

export default Home;
