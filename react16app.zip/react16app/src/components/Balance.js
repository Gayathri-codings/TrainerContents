import React from 'react';
import { useBank } from '../context/BankContext';

function Balance() {
  const { state } = useBank();
  return (
    <div className="container">
      <h2>Account Balance</h2>
      <p className="fs-4">
        Your current balance is <strong>${state.balance}</strong>
      </p>
      <h4>Transaction History</h4>
      {state.history.length === 0 ? (
        <p>No transactions yet.</p>
      ) : (
        <ul className="list-group col-md-4">
          {state.history.map((item, index) => (
            <li className="list-group-item" key={index}>
              {item}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default Balance;
