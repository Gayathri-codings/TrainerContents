import React from 'react';
import { NavLink } from 'react-router-dom';

function Menu() {
  return (
    <nav className="navbar navbar-expand navbar-dark bg-dark mb-4">
      <div className="container">
        <span className="navbar-brand">Murthy's Bank</span>
        <div className="navbar-nav">
          <NavLink exact to="/" className="nav-link" activeClassName="active">
            Home
          </NavLink>
          <NavLink to="/deposit" className="nav-link" activeClassName="active">
            Deposit
          </NavLink>
          <NavLink to="/withdraw" className="nav-link" activeClassName="active">
            Withdraw
          </NavLink>
          <NavLink to="/balance" className="nav-link" activeClassName="active">
            Show Balance
          </NavLink>
        </div>
      </div>
    </nav>
  );
}

export default Menu;
