import React, { useState } from 'react';
import { useBank } from '../context/BankContext';

function Deposit() {
  const { dispatch } = useBank();
  const [amount, setAmount] = useState('');
  const [message, setMessage] = useState('');

  function handleSubmit(e) {
    e.preventDefault();
    const value = Number(amount);
    if (!value || value <= 0) {
      setMessage('Please enter a valid amount.');
      return;
    }
    dispatch({ type: 'DEPOSIT', amount: value });
    setMessage(`Deposited $${value} successfully.`);
    setAmount('');
  }

  return (
    <div className="container">
      <h2>Deposit</h2>
      <form onSubmit={handleSubmit} className="col-md-4">
        <div className="mb-3">
          <label className="form-label">Amount</label>
          <input
            type="number"
            className="form-control"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="Enter amount"
          />
        </div>
        <button type="submit" className="btn btn-success">
          Deposit
        </button>
      </form>
      {message && <p className="mt-3">{message}</p>}
    </div>
  );
}

export default Deposit;
