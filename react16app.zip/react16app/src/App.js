import React from 'react';
import { Switch, Route } from 'react-router-dom';
import Menu from './components/Menu';
import Home from './components/Home';
import Deposit from './components/Deposit';
import Withdraw from './components/Withdraw';
import Balance from './components/Balance';
import { BankProvider } from './context/BankContext';

function App() {
  return (
    <BankProvider>
      <Menu />
      <Switch>
        <Route exact path="/" component={Home} />
        <Route path="/deposit" component={Deposit} />
        <Route path="/withdraw" component={Withdraw} />
        <Route path="/balance" component={Balance} />
      </Switch>
    </BankProvider>
  );
}

export default App;
