import React, { createContext, useContext, useReducer } from 'react';

const BankContext = createContext();

const initialState = {
  balance: 1000,
  history: []
};

function bankReducer(state, action) {
  switch (action.type) {
    case 'DEPOSIT':
      return {
        balance: state.balance + action.amount,
        history: [...state.history, `Deposited $${action.amount}`]
      };
    case 'WITHDRAW':
      return {
        balance: state.balance - action.amount,
        history: [...state.history, `Withdrew $${action.amount}`]
      };
    default:
      return state;
  }
}

export function BankProvider({ children }) {
  const [state, dispatch] = useReducer(bankReducer, initialState);
  return (
    <BankContext.Provider value={{ state, dispatch }}>
      {children}
    </BankContext.Provider>
  );
}

export function useBank() {
  const context = useContext(BankContext);
  if (!context) {
    throw new Error('useBank must be used within a BankProvider');
  }
  return context;
}
