- Migration Guide: React 16.x → React 19.x
=======================================

This document lists, step by step, every change that must be applied to this Banking App to move it from React 16.14 to React 19.

Recommended path: 16 → 17 → 18 → 19, one major version at a time, running the app and tests after each step.

 1. React 16 → React 17

React 17 is a "stepping stone" release — almost no new APIs. Low risk.

 Changes to apply

1. Upgrade packages
   
   npm install react@17 react-dom@17
   
2. New JSX Transform (optional but recommended) — lets you drop `import React from 'react'` in files that only use JSX.
   - Install: `npm install save-dev @babel/preset-react` 
   - No code changes are strictly required if you keep the classic transform.
3. Event delegation change — React 17 attaches event listeners to the root DOM container instead of `document`. No code changes needed for this app (we don't rely on native `document` listeners), but worth knowing if mixing with non-React widgets.
4. No `componentWillMount` etc. warnings change — not applicable, this app has no class components.

Result: package.json `react`/`react-dom` bumped to `^17.0.2`. No source file changes required for this project.
==============================================

 2. React 17 → React 18

This is the first version with real breaking changes: the root rendering API.

 Changes to apply

1. Upgrade packages
   
   npm install react@18 react-dom@18
   
2. Replace `ReactDOM.render` with `createRoot` — `ReactDOM.render` is deprecated in 18 (and removed in 19).

   `src/index.js` — before:
   jsx
   import ReactDOM from 'react-dom';

   ReactDOM.render(
     <React.StrictMode>
       <BrowserRouter>
         <App />
       </BrowserRouter>
     </React.StrictMode>,
     document.getElementById('root')
   );
   

   `src/index.js` — after:
   jsx
   import { createRoot } from 'react-dom/client';

   const root = createRoot(document.getElementById('root'));
   root.render(
     <React.StrictMode>
       <BrowserRouter>
         <App />
       </BrowserRouter>
     </React.StrictMode>
   );
   
3. Automatic batching — in React 18, state updates inside promises, timeouts, and native event handlers are now batched automatically. 

Our `Deposit.js` / `Withdraw.js` dispatch + `setState` calls inside `handleSubmit` already behave correctly either way, but worth re-testing manually.
4. `PropTypes` — this project doesn't use `prop-types`; nothing to change.

Result: `src/index.js` rewritten to use `createRoot`. No other files change.

 3. React 18 → React 19

The biggest jump. Several APIs are fully removed, and some are added that we can optionally adopt.

 Breaking changes to apply

1. Upgrade packages
   
   npm install react@19 react-dom@19
   
2. `ReactDOM.render` is removed entirely — already handled in the step above (must use `createRoot`).
   
3. String refs fully removed — not used in this project (we use hooks, not refs, for form inputs via controlled components), so no change needed.

5. `defaultProps` on function components is deprecated — not used in this project; all components rely on Context (`useBank`) or local `useState`, not `props.defaultProps`. No change needed.

6. New JSX transform is required (classic transform support dropped) — ensure the build tool (react-scripts / Vite / Babel config) uses `"jsx": "react-jsx"`. With Create React App's `react-scripts@5`, this is already the default — no change needed for this project.
7. `propTypes` on function components no longer has any effect — not used here.

These are optional improvements, listed because "use hooks wherever possible" is a goal of this project:

1. `useActionState` for the Deposit/Withdraw forms — replaces manual `useState` + `handleSubmit` with a form Action.

   `src/components/Deposit.js` — React 19 style
   
   import { useActionState } from 'react';
   import { useBank } from '../context/BankContext';

   function Deposit() {
     const { dispatch } = useBank();

     const [message, formAction] = useActionState((_prevMessage, formData) => {
       const value = Number(formData.get('amount'));
       if (!value || value <= 0) 
           return 'Please enter a valid amount.';

       dispatch({ type: 'DEPOSIT', amount: value });
       return `Deposited $${value} successfully.`;
     }, '');

     return (
       <div className="container">
         <h2>Deposit</h2>
         <form action={formAction} className="col-md-4">
           <div className="mb-3">
             <label className="form-label">Amount</label>
             <input type="number" name="amount" className="form-control" placeholder="Enter amount" />
           </div>
           <button type="submit" className="btn btn-success">Deposit</button>
         </form>
         {message && <p className="mt-3">{message}</p>}
       </div>
     );
   }
   
   (The same pattern applies to `Withdraw.js`.)

2. `use()` hook — useful if balance/history is later fetched from an async API instead of local state; not needed while state is purely local via `useReducer`.

Result: package.json `react`/`react-dom` bumped to `^19.x`. 

`src/index.js` already updated in the 18 step. Form components may be refactored to `useActionState`, but the existing `useState`-based forms continue to work unchanged in React 19 — this step is optional polish.

 4. `react-router-dom` v5 → v6 (required alongside React 18/19)

`react-router-dom@5` works fine on React 18 but is not compatible with React 19's stricter typings/behavior in practice, and v6 is the actively maintained line — upgrade it together with the React 18 step.

 Changes to apply

1. Upgrade package
   
   npm install react-router-dom@6
   
2. `Switch` → `Routes`, and `component={X}` → `element={<X />}`

   `src/App.js` — before (v5):
x
   import { Switch, Route } from 'react-router-dom';
   // ...
   <Switch>
     <Route exact path="/" component={Home} />
     <Route path="/deposit" component={Deposit} />
     <Route path="/withdraw" component={Withdraw} />
     <Route path="/balance" component={Balance} />
   </Switch>
   

   `src/App.js` — after (v6):
   jsx
   import { Routes, Route } from 'react-router-dom';
   // ...
   <Routes>
     <Route path="/" element={<Home />} />
     <Route path="/deposit" element={<Deposit />} />
     <Route path="/withdraw" element={<Withdraw />} />
     <Route path="/balance" element={<Balance />} />
   </Routes>
   
   Note: `exact` is no longer needed in v6 — matching is exact by default.

3. `NavLink`'s `activeClassName` prop is removed — v6 passes an `isActive` boolean into a function `className` prop instead.

   `src/components/Menu.js` — before (v5):
   jsx
   <NavLink exact to="/" className="nav-link" activeClassName="active">Home</NavLink>
   

   `src/components/Menu.js` — after (v6):
   jsx
   <NavLink
     to="/"
     className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}
   >
     Home
   </NavLink>
   
4. `useHistory()` → `useNavigate()` — not used in this project currently (forms don't redirect), but relevant if that's added later: `history.push('/balance')` becomes `navigate('/balance')`.

5. No more `<Switch>` fallback via extra unmatched `<Route>` — a "not found" page uses `<Route path="" element={<NotFound />} />` in v6.

Result: `src/App.js` and `src/components/Menu.js` updated as shown above. `BrowserRouter` import/usage in `src/index.js` is unchanged — v6 keeps the same top-level `<BrowserRouter>` API.


 5. Summary Checklist

- [ ] `package.json`: bump `react`, `react-dom` → `19.x`; bump `react-router-dom` → `6.x`.

- [ ] `src/index.js`: `ReactDOM.render(...)` → `createRoot(...).render(...)`.

- [ ] `src/App.js`: `Switch` → `Routes`; `component={X}` → `element={<X />}`; drop `exact`.

- [ ] `src/components/Menu.js`: `activeClassName` → function-based `className` prop on `NavLink`.

- [ ] (Optional) `src/components/Deposit.js` / `Withdraw.js`: adopt `useActionState` for form handling.

- [ ] Re-run `npm start` and manually re-test Deposit, Withdraw, and Show Balance flows.
===========================================================

