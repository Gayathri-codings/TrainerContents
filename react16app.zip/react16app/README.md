# Simple Banking App (React 16.x)

A beginner-friendly training project that simulates a basic bank account: deposit money, withdraw money, and view your balance and transaction history. Built with **React 16**, **react-router-dom v5**, **React Hooks**, and **Bootstrap 5 (via CDN)**.

## Tech Stack

| Tool | Version | Purpose |
|---|---|---|
| React | 16.14.x | UI library |
| react-dom | 16.14.x | DOM renderer |
| react-router-dom | 5.3.x | Client-side routing / menu |
| react-scripts | 5.0.1 | Build tooling (CRA) |
| Bootstrap | 5.3.x (CDN link in `public/index.html`) | Styling |

> Bootstrap is **not** installed via npm — it is loaded directly from a CDN `<link>` tag in `public/index.html`, as requested.

## Project Structure

```
public/
  index.html          # Bootstrap CDN <link> lives here
src/
  index.js            # App entry point, ReactDOM.render + BrowserRouter
  index.css           # Minimal global styles
  App.js              # Routes (Switch/Route) + BankProvider
  context/
    BankContext.js    # useReducer + useContext based global state (balance, history)
  components/
    Menu.js           # Top navigation menu (NavLink)
    Home.js           # Landing page showing current balance
    Deposit.js        # Deposit form
    Withdraw.js        # Withdraw form
    Balance.js        # Balance + transaction history
```

## Features

- **Menu / navigation** via `react-router-dom` (`BrowserRouter`, `Switch`, `Route`, `NavLink`).
- **Deposit** — add funds to the account balance.
- **Withdraw** — remove funds, with a check against insufficient balance.
- **Show Balance** — view current balance and a running transaction history.
- Global account state is shared across pages using the **Context API + `useReducer`** (no class components, no prop drilling, no external state library) — hooks are used wherever possible (`useState`, `useContext`, `useReducer`).
- Minimal, intentionally simple styling — relies on Bootstrap utility classes so the React/JS concepts stay the focus (this is a training project, not a production UI).

## Getting Started

```bash
npm install
npm start
```

The app runs at [http://localhost:3000](http://localhost:3000).

## Available Scripts

- `npm start` — run the app in development mode.
- `npm run build` — create a production build.
- `npm test` — run tests (react-scripts default test runner).

## How the Banking Logic Works

1. `BankProvider` (in `src/context/BankContext.js`) wraps the whole app and holds `{ balance, history }` in a `useReducer` reducer.
2. `Deposit.js` and `Withdraw.js` dispatch `DEPOSIT` / `WITHDRAW` actions with a numeric amount.
3. The reducer updates the balance and appends a human-readable entry to `history`.
4. `Balance.js` and `Home.js` read the shared state via the `useBank()` custom hook (`useContext` wrapper) and re-render automatically.

## TODO

- [ ] Add input validation feedback styling (e.g. red border on invalid amount).
- [ ] Persist balance/history to `localStorage` so it survives a page refresh.
- [ ] Add a "Transfer" page (move money between two mock accounts).
- [ ] Add unit tests for the `bankReducer` function.
- [ ] Add unit tests for `Deposit`, `Withdraw`, and `Balance` components (React Testing Library).
- [ ] Add a confirmation modal before large withdrawals.
- [ ] Add multi-currency support.
- [ ] Add authentication (mock login) before allowing access to the menu.
- [ ] Replace the Bootstrap CDN `<link>` with an npm-installed Bootstrap package (optional, if offline support is needed).
- [ ] Migrate the project to React 19 — see [`MIGRATION.md`](./MIGRATION.md) for the full step-by-step guide.

## License

For training/educational use only.
