//npm install @react-spring/web
/*
useSpring Hook: Manages the spring animation. Here, opacity and scale are animated properties. We use api.start to trigger 
changes in these properties when the card is hovered.

Event Handlers: handleMouseEnter and handleMouseLeave are used
 to start animations when the mouse enters or leaves the card.

animated.div: This is a React Spring-enhanced div that uses the 
animated properties from the useSpring hook.

Styling: The card class in CSS defines the basic appearance of 
the card. The transform and opacity properties are animated 
based on the state managed by React Spring.
*/
import React from 'react';
import { useSpring, animated } from '@react-spring/web';
import './SpringAnimation.css'; // Import the stylesheet for basic styles

const CardComponent = () => {
  // Spring configuration for animation
  const [props, api] = useSpring(() => ({
    opacity: 1,
    scale: 1,
    config: { mass: 5, tension: 350, friction: 40 },
  }));

  // Event handlers for mouse events
  const handleMouseEnter = () => {
    api.start({
      opacity: 1,
      scale: 1.05,
    });
  };

  const handleMouseLeave = () => {
    api.start({
      opacity: 1,
      scale: 1,
    });
  };

  return (
    <animated.div
      className="card"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      style={{
        ...props,
        transform: props.scale.to(s => `scale(${s})`),
        opacity: props.opacity,
      }}
    >
      <div className="card-content">
        <h2>Card Title</h2>
        <p>Welcome to Bank of America</p>
      </div>
    </animated.div>
  );
};

export default CardComponent;
