import React from 'react';

function SecureComponent() {
  const handleClick = () => {
    alert('Button clicked!');
  };

  return (
    <button onClick={handleClick}>Click me</button>
  );
}

export default SecureComponent;
