<meta http-equiv="Content-Security-Policy" 
content="default-src 'self'; script-src 'self'; style-src 'self';">
