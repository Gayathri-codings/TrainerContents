import React from 'react';

function SafeComponent() {
  // Unsafe example
   //const dangerousHtml = "<img src='x' onerror='alert(1)' />";
   //return <div dangerouslySetInnerHTML={{ __html: dangerousHtml }} />;
  
  // Safe example
  return <div>Safe content here</div>;
}

export default SafeComponent;