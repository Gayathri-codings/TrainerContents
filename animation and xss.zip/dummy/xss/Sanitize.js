import React, { useState } from 'react';
import DOMPurify from 'dompurify';
//npm install DOMPurify
function SanitizedComponent() {
  const [input, setInput] = useState('');

  const handleChange = (e) => {
    setInput(e.target.value);
  };

  const sanitizedHtml = DOMPurify.sanitize(input);

  return (
    <div>
      <textarea value={input} onChange={handleChange} 
          placeholder="Enter HTML" />
      <div dangerouslySetInnerHTML={{ __html: sanitizedHtml }} />
    </div>
  );
}

export default SanitizedComponent;
