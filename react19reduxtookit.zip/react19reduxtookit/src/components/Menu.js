// [REACT 19 MIGRATION] Removed unused `import React from 'react'` (new JSX transform).
import { NavLink } from 'react-router-dom';

// [REACT 19 MIGRATION] Router v6 removed NavLink's `activeClassName` prop.
// `className` now accepts a function that receives `{ isActive }`.
// Before: className="nav-link" activeClassName="active"
const navClass = ({ isActive }) => `nav-link${isActive ? ' active' : ''}`;

function Menu() {
  return (
    <nav className="navbar navbar-expand navbar-dark bg-dark mb-4">
      <div className="container">
        <span className="navbar-brand">Murthy's Bank</span>
        <div className="navbar-nav">
          {/* [REACT 19 MIGRATION] Router v6: `exact` -> `end`. Without `end`,
              the "/" link would stay highlighted on every page. */}
          <NavLink end to="/" className={navClass}>
            Home
          </NavLink>
          <NavLink to="/deposit" className={navClass}>
            Deposit
          </NavLink>
          <NavLink to="/withdraw" className={navClass}>
            Withdraw
          </NavLink>
          <NavLink to="/balance" className={navClass}>
            Show Balance
          </NavLink>
        </div>
      </div>
    </nav>
  );
}

export default Menu;
