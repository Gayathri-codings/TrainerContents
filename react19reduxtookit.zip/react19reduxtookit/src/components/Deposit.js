// [REACT 19 MIGRATION] Removed default `React` import and `useState`;
// the form now uses the React 19 `useActionState` hook.
import { useActionState } from 'react';
// [REDUX TOOLKIT MIGRATION] Before: `dispatch` from `useBank()` (Context).
// After: `useDispatch` from react-redux + the `deposit` action creator.
import { useDispatch } from 'react-redux';
import { deposit } from '../store/bankSlice';

function Deposit() {
  const dispatch = useDispatch();

  // [REACT 19 MIGRATION] Before: two `useState` hooks (amount, message) plus a
  // `handleSubmit(e)` that called e.preventDefault() and cleared the input.
  // After: a form Action. React passes the submitted FormData, the returned
  // value becomes `message`, and React resets the (uncontrolled) form for us.
  const [message, formAction] = useActionState((_prevMessage, formData) => {
    const value = Number(formData.get('amount'));
    if (!value || value <= 0) {
      return 'Please enter a valid amount.';
    }
    // [REDUX TOOLKIT MIGRATION] Before: dispatch({ type: 'DEPOSIT', amount: value })
    dispatch(deposit(value));
    return `Deposited $${value} successfully.`;
  }, '');

  return (
    <div className="container">
      <h2>Deposit</h2>
      {/* [REACT 19 MIGRATION] Before: onSubmit={handleSubmit}. After: action={formAction}. */}
      <form action={formAction} className="col-md-4">
        <div className="mb-3">
          <label className="form-label">Amount</label>
          {/* [REACT 19 MIGRATION] Controlled input (value/onChange) replaced by an
              uncontrolled input with `name`, read via formData.get('amount'). */}
          <input
            type="number"
            name="amount"
            className="form-control"
            placeholder="Enter amount"
          />
        </div>
        <button type="submit" className="btn btn-success">
          Deposit
        </button>
      </form>
      {message && <p className="mt-3">{message}</p>}
    </div>
  );
}

export default Deposit;
