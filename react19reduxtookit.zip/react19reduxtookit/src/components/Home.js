// [REACT 19 MIGRATION] Removed unused `import React from 'react'` (new JSX transform).
// [REDUX TOOLKIT MIGRATION] Before: `useBank()` from Context. After: `useSelector`.
import { useSelector } from 'react-redux';
import { selectBalance } from '../store/bankSlice';

function Home() {
  const balance = useSelector(selectBalance);
  return (
    <div className="container">
      <h2 class="bg-primary text-light">Welcome to Murthy's Bank with Redux-Toolkit</h2>
      <p>Current balance: <strong>${balance}</strong></p>
      <p>Use the menu above to deposit, withdraw or check your balance.</p>
      <footer>
        <h6 class="bg-dark text-light text-center">Copyright Reserved. Project done with React 19.x & redux-toolkit</h6>
      </footer>
    </div>
  );
}

export default Home;
