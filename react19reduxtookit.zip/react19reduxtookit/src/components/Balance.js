// [REACT 19 MIGRATION] Removed unused `import React from 'react'` (new JSX transform).
// [REDUX TOOLKIT MIGRATION] Before: `useBank()` from Context. After: `useSelector`.
import { useSelector } from 'react-redux';
import { selectBalance, selectHistory } from '../store/bankSlice';

function Balance() {
  const balance = useSelector(selectBalance);
  const history = useSelector(selectHistory);
  return (
    <div className="container">
      <h2>Account Balance</h2>
      <p className="fs-4">
        Your current balance is <strong>${balance}</strong>
      </p>
      <h4>Transaction History</h4>
      {history.length === 0 ? (
        <p>No transactions yet.</p>
      ) : (
        <ul className="list-group col-md-4">
          {history.map((item, index) => (
            <li className="list-group-item" key={index}>
              {item}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default Balance;
