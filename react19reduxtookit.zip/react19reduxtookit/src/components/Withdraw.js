// [REACT 19 MIGRATION] Removed default `React` import and `useState`;
// the form now uses the React 19 `useActionState` hook.
import { useActionState } from 'react';
// [REDUX TOOLKIT MIGRATION] Before: `state` + `dispatch` from `useBank()` (Context).
// After: `useSelector` for the balance, `useDispatch` + `withdraw` action creator.
import { useDispatch, useSelector } from 'react-redux';
import { selectBalance, withdraw } from '../store/bankSlice';

function Withdraw() {
  const balance = useSelector(selectBalance);
  const dispatch = useDispatch();

  // [REACT 19 MIGRATION] Before: `useState` for amount + message and a
  // `handleSubmit(e)` with e.preventDefault(). After: a form Action whose
  // return value is the status message. React resets the form after submit.
  const [message, formAction] = useActionState((_prevMessage, formData) => {
    const value = Number(formData.get('amount'));
    if (!value || value <= 0) {
      return 'Please enter a valid amount.';
    }
    if (value > balance) {
      return 'Insufficient balance.';
    }
    // [REDUX TOOLKIT MIGRATION] Before: dispatch({ type: 'WITHDRAW', amount: value })
    dispatch(withdraw(value));
    return `Withdrew $${value} successfully.`;
  }, '');

  return (
    <div className="container">
      <h2>Withdraw</h2>
      {/* [REACT 19 MIGRATION] Before: onSubmit={handleSubmit}. After: action={formAction}. */}
      <form action={formAction} className="col-md-4">
        <div className="mb-3">
          <label className="form-label">Amount</label>
          {/* [REACT 19 MIGRATION] Controlled input replaced by uncontrolled `name="amount"`. */}
          <input
            type="number"
            name="amount"
            className="form-control"
            placeholder="Enter amount"
          />
        </div>
        <button type="submit" className="btn btn-danger">
          Withdraw
        </button>
      </form>
      {message && <p className="mt-3">{message}</p>}
    </div>
  );
}

export default Withdraw;
