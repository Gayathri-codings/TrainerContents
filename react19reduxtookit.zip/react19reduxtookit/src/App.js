// [REACT 19 MIGRATION] Removed unused `import React from 'react'` (new JSX transform).
// [REACT 19 MIGRATION] react-router-dom v5 -> v6: `Switch` was replaced by `Routes`.
import { Routes, Route } from 'react-router-dom';
import Menu from './components/Menu';
import Home from './components/Home';
import Deposit from './components/Deposit';
import Withdraw from './components/Withdraw';
import Balance from './components/Balance';
// [REDUX TOOLKIT MIGRATION] Removed `BankProvider` (Context API). The Redux
// <Provider> now wraps the app in `src/index.js`.

function App() {
  return (
    <>
      <Menu />
      
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/deposit" element={<Deposit />} />
        <Route path="/withdraw" element={<Withdraw />} />
        <Route path="/balance" element={<Balance />} />
      </Routes>
    </>
  );
}

export default App;
