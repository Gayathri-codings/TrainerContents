import { deposit, withdraw } from './bankSlice';

describe('bank action creators', () => {
  describe('deposit', () => {
    test('has the slice-prefixed action type', () => {
      expect(deposit.type).toBe('bank/deposit');
    });

    test('creates an action with the amount as payload', () => {
      expect(deposit(100)).toEqual({ type: 'bank/deposit', payload: 100 });
    });

    test('passes decimal amounts through unchanged', () => {
      expect(deposit(12.5).payload).toBe(12.5);
    });

    test('match() recognises its own actions only', () => {
      expect(deposit.match(deposit(50))).toBe(true);
      expect(deposit.match(withdraw(50))).toBe(false);
    });
  });

  describe('withdraw', () => {
    test('has the slice-prefixed action type', () => {
      expect(withdraw.type).toBe('bank/withdraw');
    });

    test('creates an action with the amount as payload', () => {
      expect(withdraw(400)).toEqual({ type: 'bank/withdraw', payload: 400 });
    });

    test('passes decimal amounts through unchanged', () => {
      expect(withdraw(0.99).payload).toBe(0.99);
    });

    test('match() recognises its own actions only', () => {
      expect(withdraw.match(withdraw(50))).toBe(true);
      expect(withdraw.match(deposit(50))).toBe(false);
    });
  });
});
