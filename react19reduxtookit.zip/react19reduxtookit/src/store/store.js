// [REDUX TOOLKIT MIGRATION] Single Redux store for the app. Replaces the
// `useReducer` inside `BankProvider`. `configureStore` also wires up the
// Redux DevTools extension and dev-only checks (immutability/serializability).
import { configureStore } from '@reduxjs/toolkit';
import bankReducer from './bankSlice';

export const store = configureStore({
  reducer: {
    bank: bankReducer
  }
});
