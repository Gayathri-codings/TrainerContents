// [REDUX TOOLKIT MIGRATION] Replaces the `bankReducer` + `initialState` that
// lived in `src/context/BankContext.js`. `createSlice` generates the action
// creators and action types for us, and Immer lets the reducers "mutate" state.
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  balance: 1000,
  history: []
};

const bankSlice = createSlice({
  name: 'bank',
  initialState,
  reducers: {
    // Before: case 'DEPOSIT': return { balance: ..., history: [...] }
    deposit(state, action) {
      state.balance += action.payload;
      state.history.push(`Deposited $${action.payload}`);
    },
    // Before: case 'WITHDRAW': return { balance: ..., history: [...] }
    withdraw(state, action) {
      // Ignore withdrawals that would overdraw the account.
      if (action.payload > state.balance) {
        return;
      }
      state.balance -= action.payload;
      state.history.push(`Withdrew $${action.payload}`);
    }
  }
});

// Action creators: dispatch(deposit(100)) -> { type: 'bank/deposit', payload: 100 }
export const { deposit, withdraw } = bankSlice.actions;

// Selectors: components read state through these instead of `useBank().state`.
export const selectBalance = (state) => state.bank.balance;
export const selectHistory = (state) => state.bank.history;

export default bankSlice.reducer;
