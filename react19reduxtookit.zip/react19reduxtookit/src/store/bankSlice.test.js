import { configureStore } from '@reduxjs/toolkit';
import bankReducer, {
  deposit,
  withdraw,
  selectBalance,
  selectHistory
} from './bankSlice';
import { store } from './store';

const initialState = { balance: 1000, history: [] };

describe('bankSlice reducer', () => {
  test('returns the initial state', () => {
    expect(bankReducer(undefined, { type: 'unknown' })).toEqual(initialState);
  });

  test('ignores unrelated actions', () => {
    const state = { balance: 500, history: ['Deposited $500'] };
    expect(bankReducer(state, { type: 'other/action', payload: 99 })).toBe(state);
  });

  describe('deposit', () => {
    test('adds to the balance and records history', () => {
      const state = bankReducer(undefined, deposit(250));
      expect(state.balance).toBe(1250);
      expect(state.history).toEqual(['Deposited $250']);
    });

    test('appends to existing history', () => {
      const state = bankReducer(
        { balance: 1000, history: ['Withdrew $100'] },
        deposit(50)
      );
      expect(state.history).toEqual(['Withdrew $100', 'Deposited $50']);
    });
  });

  describe('withdraw', () => {
    test('subtracts from the balance and records history', () => {
      const state = bankReducer(initialState, withdraw(400));
      expect(state.balance).toBe(600);
      expect(state.history).toEqual(['Withdrew $400']);
    });

    test('can withdraw the full balance', () => {
      expect(bankReducer(initialState, withdraw(1000)).balance).toBe(0);
    });

    test('ignores a withdrawal larger than the balance', () => {
      const state = { balance: 1000, history: ['Deposited $1000'] };
      expect(bankReducer(state, withdraw(1500))).toBe(state);
    });

    test('rejects an overdraft by even a fraction', () => {
      expect(bankReducer(initialState, withdraw(1000.01))).toBe(initialState);
    });
  });

  test('handles a sequence of transactions in order', () => {
    const actions = [deposit(200), withdraw(50), deposit(25), withdraw(175)];
    const state = actions.reduce(bankReducer, initialState);

    expect(state.balance).toBe(1000);
    expect(state.history).toEqual([
      'Deposited $200',
      'Withdrew $50',
      'Deposited $25',
      'Withdrew $175'
    ]);
  });

  test('does not mutate the previous state', () => {
    const prev = { balance: 1000, history: ['Deposited $1'] };
    const snapshot = JSON.parse(JSON.stringify(prev));

    const next = bankReducer(prev, deposit(100));

    expect(prev).toEqual(snapshot);
    expect(next).not.toBe(prev);
    expect(next.history).not.toBe(prev.history);
  });
});

describe('bank selectors', () => {
  const rootState = {
    bank: { balance: 750, history: ['Withdrew $250'] }
  };

  test('selectBalance returns the balance', () => {
    expect(selectBalance(rootState)).toBe(750);
  });

  test('selectHistory returns the history', () => {
    expect(selectHistory(rootState)).toEqual(['Withdrew $250']);
  });
});

describe('store integration', () => {
  const makeStore = () => configureStore({ reducer: { bank: bankReducer } });

  test('app store registers the bank slice with its initial state', () => {
    expect(store.getState()).toEqual({ bank: initialState });
  });

  test('dispatched actions update state read via selectors', () => {
    const testStore = makeStore();

    testStore.dispatch(deposit(300));
    testStore.dispatch(withdraw(100));

    const state = testStore.getState();
    expect(selectBalance(state)).toBe(1200);
    expect(selectHistory(state)).toEqual(['Deposited $300', 'Withdrew $100']);
  });

  test('notifies subscribers on each dispatch', () => {
    const testStore = makeStore();
    const listener = jest.fn();
    testStore.subscribe(listener);

    testStore.dispatch(deposit(10));
    testStore.dispatch(withdraw(5));

    expect(listener).toHaveBeenCalledTimes(2);
  });
});
