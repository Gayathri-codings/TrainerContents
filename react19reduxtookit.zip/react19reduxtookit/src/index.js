// [REACT 19 MIGRATION] Removed `import React from 'react'` — the new JSX
// transform (default in react-scripts 5, required by React 19) no longer
// needs React in scope. `React.StrictMode` is now imported as `StrictMode`.
import { StrictMode } from 'react';
// [REACT 19 MIGRATION] `ReactDOM.render` was REMOVED in React 19.
// Before: import ReactDOM from 'react-dom';
// After:  `createRoot` from 'react-dom/client' (introduced in React 18).
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
// [REDUX TOOLKIT MIGRATION] <Provider> makes the Redux store available to every
// component (replaces <BankProvider> from the old Context API setup).
import { Provider } from 'react-redux';
import { store } from './store/store';
import App from './App';
import './index.css';

const root = createRoot(document.getElementById('root'));
root.render(
  <StrictMode>
    <Provider store={store}>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </Provider>
  </StrictMode>
);
