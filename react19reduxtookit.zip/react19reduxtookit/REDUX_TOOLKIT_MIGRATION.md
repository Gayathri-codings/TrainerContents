# Redux Toolkit Migration: Context API + `useReducer` → Redux Toolkit

This file records how the Banking App's global state (`balance` and `history`) was moved from the React Context API (`src/context/BankContext.js`) to **Redux Toolkit** (RTK) with **react-redux**.

Every changed spot in the source has this comment tag on it:

```
[REDUX TOOLKIT MIGRATION]
```

> Tip: in VS Code, search the `src/` folder for `REDUX TOOLKIT MIGRATION` to jump to each change.

The app looks and works the same as before. Only the state management underneath changed.

---

## Before vs. after (overview)

| Concern | Before (Context API) | After (Redux Toolkit) |
|---|---|---|
| Where state lives | `useReducer` inside `<BankProvider>` | A single Redux store (`configureStore`) |
| Reducer | Hand-written `switch` in `bankReducer` | `createSlice` reducers (Immer, "mutating" syntax) |
| Action types | String literals `'DEPOSIT'`, `'WITHDRAW'` | Generated: `'bank/deposit'`, `'bank/withdraw'` |
| Dispatching | `dispatch({ type: 'DEPOSIT', amount })` | `dispatch(deposit(amount))` |
| Reading state | `const { state } = useBank()` | `useSelector(selectBalance)` / `useSelector(selectHistory)` |
| App wrapper | `<BankProvider>` in `App.js` | `<Provider store={store}>` in `index.js` |
| Debugging | None | Redux DevTools browser extension works automatically |

### New data flow

```
Deposit / Withdraw  --dispatch(deposit(x) / withdraw(x))-->  store (bankSlice reducer)
                                                                  |
Home / Balance / Withdraw  <--useSelector(selectBalance/History)--+
```

---

## Step-by-step

### Step 1: Install the packages

```bash
npm install @reduxjs/toolkit react-redux
```

| Package | Version installed | Purpose |
|---|---|---|
| `@reduxjs/toolkit` | `^2.13.0` | `configureStore`, `createSlice` (includes Redux core + Immer) |
| `react-redux` | `^9.3.0` | `<Provider>`, `useSelector`, `useDispatch` (supports React 19) |

### Step 2: Create the slice (`src/store/bankSlice.js`, new file)

The reducer logic from `BankContext.js` moves into a slice. `createSlice` generates the action creators for us, and Immer lets the reducers write `state.balance += ...` while still producing a new immutable state.

```js
import { createSlice } from '@reduxjs/toolkit';

const initialState = { balance: 1000, history: [] };

const bankSlice = createSlice({
  name: 'bank',
  initialState,
  reducers: {
    deposit(state, action) {
      state.balance += action.payload;
      state.history.push(`Deposited $${action.payload}`);
    },
    withdraw(state, action) {
      state.balance -= action.payload;
      state.history.push(`Withdrew $${action.payload}`);
    }
  }
});

export const { deposit, withdraw } = bankSlice.actions;
export const selectBalance = (state) => state.bank.balance;
export const selectHistory = (state) => state.bank.history;
export default bankSlice.reducer;
```

How the old reducer maps to the new one:

| Old (`bankReducer`) | New (`bankSlice`) |
|---|---|
| `case 'DEPOSIT': return { balance: state.balance + action.amount, history: [...state.history, ...] }` | `deposit(state, action) { state.balance += action.payload; state.history.push(...) }` |
| `case 'WITHDRAW': ...` | `withdraw(state, action) { ... }` |
| `default: return state` | Handled automatically by `createSlice` |
| `action.amount` | `action.payload` (the RTK convention) |

The selectors (`selectBalance`, `selectHistory`) are exported so components don't need to know the shape of the store (`state.bank.*`).

### Step 3: Create the store (`src/store/store.js`, new file)

```js
import { configureStore } from '@reduxjs/toolkit';
import bankReducer from './bankSlice';

export const store = configureStore({
  reducer: {
    bank: bankReducer
  }
});
```

The `bank` key is why the selectors read `state.bank.balance`. `configureStore` also turns on Redux DevTools and the development-only checks for accidental mutation and non-serializable values.

### Step 4: Provide the store (`src/index.js`)

Wrap the app with react-redux's `<Provider>`:

```jsx
import { Provider } from 'react-redux';
import { store } from './store/store';

root.render(
  <StrictMode>
    <Provider store={store}>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </Provider>
  </StrictMode>
);
```

### Step 5: Remove `BankProvider` (`src/App.js`)

| Before | After |
|---|---|
| `import { BankProvider } from './context/BankContext';` | (removed) |
| `<BankProvider> ... </BankProvider>` | `<> ... </>` (fragment) |

### Step 6: Update the components that read state

**`src/components/Home.js`**

```jsx
// Before
const { state } = useBank();
... ${state.balance}

// After
import { useSelector } from 'react-redux';
import { selectBalance } from '../store/bankSlice';

const balance = useSelector(selectBalance);
... ${balance}
```

**`src/components/Balance.js`**

```jsx
// After
const balance = useSelector(selectBalance);
const history = useSelector(selectHistory);
```

`state.history.length` / `state.history.map` became `history.length` / `history.map`.

### Step 7: Update the components that dispatch actions

**`src/components/Deposit.js`**

```jsx
// Before
const { dispatch } = useBank();
dispatch({ type: 'DEPOSIT', amount: value });

// After
import { useDispatch } from 'react-redux';
import { deposit } from '../store/bankSlice';

const dispatch = useDispatch();
dispatch(deposit(value));
```

**`src/components/Withdraw.js`** both reads and dispatches:

```jsx
// Before
const { state, dispatch } = useBank();
if (value > state.balance) return 'Insufficient balance.';
dispatch({ type: 'WITHDRAW', amount: value });

// After
import { useDispatch, useSelector } from 'react-redux';
import { selectBalance, withdraw } from '../store/bankSlice';

const balance = useSelector(selectBalance);
const dispatch = useDispatch();
if (value > balance) return 'Insufficient balance.';
dispatch(withdraw(value));
```

The React 19 `useActionState` form Actions from the earlier migration are unchanged. Only the source of `dispatch` and `balance` changed.

### Step 8: Delete the old Context

`src/context/BankContext.js` (and the now-empty `src/context/` folder) was deleted. Nothing imports it anymore.

### Step 9: Add reducer unit tests (`src/store/bankSlice.test.js`, new file)

A slice reducer is a plain function, so it is easy to test without rendering anything:

```js
import bankReducer, { deposit, withdraw } from './bankSlice';

test('deposit adds to the balance and records history', () => {
  const state = bankReducer(undefined, deposit(250));
  expect(state.balance).toBe(1250);
  expect(state.history).toEqual(['Deposited $250']);
});
```

The file has three tests: initial state, deposit, and withdraw. This also covers the README TODO "Add unit tests for the `bankReducer` function".

### Step 10: Verify

```bash
CI=true npm run build                 # treats lint warnings as errors
CI=true npx react-scripts test --watchAll=false
```

Results:

- Production build compiles with no warnings.
- All 3 reducer tests pass.
- Manual click-through (`npm start`) has not been done yet. See the checklist below.

---

## Final project structure

```
src/
  index.js            # createRoot + <Provider store={store}> + BrowserRouter
  App.js              # Menu + Routes (no more BankProvider)
  store/
    store.js          # configureStore({ reducer: { bank } })
    bankSlice.js      # createSlice: deposit / withdraw, selectors
    bankSlice.test.js # reducer unit tests
  components/
    Menu.js           # unchanged
    Home.js           # useSelector(selectBalance)
    Deposit.js        # useDispatch + deposit()
    Withdraw.js       # useSelector + useDispatch + withdraw()
    Balance.js        # useSelector(selectBalance / selectHistory)
```

## Summary checklist

- [x] Installed `@reduxjs/toolkit` and `react-redux`
- [x] Created `src/store/bankSlice.js` (reducers, actions, selectors)
- [x] Created `src/store/store.js` with `configureStore`
- [x] Wrapped the app in `<Provider store={store}>` in `src/index.js`
- [x] Removed `<BankProvider>` from `src/App.js`
- [x] `Home.js` and `Balance.js` now use `useSelector`
- [x] `Deposit.js` and `Withdraw.js` now use `useDispatch` + action creators
- [x] Deleted `src/context/BankContext.js`
- [x] Added reducer unit tests (passing)
- [x] Production build passes
- [ ] Manual click-through test (`npm start`): deposit, withdraw (including "Insufficient balance"), and check history on Show Balance
