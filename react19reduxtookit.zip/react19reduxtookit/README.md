# Simple Banking App (React 19)

A beginner-friendly training project that simulates a basic bank account: deposit money, withdraw money, and view your balance and transaction history. Built with **React 19**, **react-router-dom v6**, **Redux Toolkit**, **React Hooks**, and **Bootstrap 5 (via CDN)**.

## Tech Stack

| Tool | Version | Purpose |
|---|---|---|
| React | 19.x | UI library |
| react-dom | 19.x | DOM renderer |
| react-router-dom | 6.x | Client-side routing / menu |
| @reduxjs/toolkit | 2.x | Global state (store + slice) |
| react-redux | 9.x | React bindings (`Provider`, `useSelector`, `useDispatch`) |
| react-scripts | 5.0.1 | Build tooling (CRA) |
| Bootstrap | 5.3.x (CDN link in `public/index.html`) | Styling |

> Bootstrap is **not** installed via npm — it is loaded directly from a CDN `<link>` tag in `public/index.html`, as requested.

## Project Structure

```
public/
  index.html          # Bootstrap CDN <link> lives here
src/
  index.js            # App entry point, createRoot + Redux <Provider> + BrowserRouter
  index.css           # Minimal global styles
  App.js              # Routes (Routes/Route)
  store/
    store.js          # configureStore — the single Redux store
    bankSlice.js      # createSlice: balance + history, deposit/withdraw actions, selectors
    bankSlice.test.js # Reducer unit tests
  components/
    Menu.js           # Top navigation menu (NavLink)
    Home.js           # Landing page showing current balance
    Deposit.js        # Deposit form
    Withdraw.js        # Withdraw form
    Balance.js        # Balance + transaction history
```

## Features

- **Menu / navigation** via `react-router-dom` (`BrowserRouter`, `Routes`, `Route`, `NavLink`).
- **Deposit** — add funds to the account balance.
- **Withdraw** — remove funds, with a check against insufficient balance.
- **Show Balance** — view current balance and a running transaction history.
- Global account state is managed with **Redux Toolkit** (`createSlice` + `configureStore`) and read/updated via the `useSelector` / `useDispatch` hooks from `react-redux` — no class components, no prop drilling.
- Minimal, intentionally simple styling — relies on Bootstrap utility classes so the React/JS concepts stay the focus (this is a training project, not a production UI).

## Getting Started

```bash
npm install
npm start
```

The app runs at [http://localhost:3000](http://localhost:3000).

## Available Scripts

- `npm start` — run the app in development mode.
- `npm run build` — create a production build.
- `npm test` — run tests (react-scripts default test runner).

## How the Banking Logic Works

1. The Redux store (`src/store/store.js`) holds `{ balance, history }` under `state.bank`, managed by `bankSlice` (`src/store/bankSlice.js`). `<Provider>` in `src/index.js` makes it available to every component.
2. `Deposit.js` and `Withdraw.js` call `dispatch(deposit(amount))` / `dispatch(withdraw(amount))`.
3. The reducer updates the balance and appends a human-readable entry to `history`.
4. `Balance.js` and `Home.js` read the state with `useSelector(selectBalance)` / `useSelector(selectHistory)` and re-render automatically.

## TODO

- [ ] Add input validation feedback styling (e.g. red border on invalid amount).
- [ ] Persist balance/history to `localStorage` so it survives a page refresh.
- [ ] Add a "Transfer" page (move money between two mock accounts).
- [x] Add unit tests for the bank reducer (`src/store/bankSlice.test.js`).
- [ ] Add unit tests for `Deposit`, `Withdraw`, and `Balance` components (React Testing Library).
- [ ] Add a confirmation modal before large withdrawals.
- [ ] Add multi-currency support.
- [ ] Add authentication (mock login) before allowing access to the menu.
- [ ] Replace the Bootstrap CDN `<link>` with an npm-installed Bootstrap package (optional, if offline support is needed).
- [x] Migrate the project to React 19 — see [`MIGRATION_CHANGES.md`](./MIGRATION_CHANGES.md) for what changed (plan in [`MIGRATION.md`](./MIGRATION.md)).
- [x] Move state management from Context API to Redux Toolkit — see [`REDUX_TOOLKIT_MIGRATION.md`](./REDUX_TOOLKIT_MIGRATION.md).

## License

For training/educational use only.
